extends CharacterBody2D


const SPEED = 75.0
const JUMP_VELOCITY = -400.0

var velocidad_actual = SPEED

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
	
	if not $Izquierda.is_colliding():
		velocity.x=-velocidad_actual
	else:
		velocity.x=-velocidad_actual*2
	move_and_slide()


func _on_muerto_body_entered(body: Node2D) -> void:
	if body.name == "Prota":
		print("Has muerto")


func _on_morir_body_entered(body: Node2D) -> void:
	if body.name == "Prota":
		queue_free()
